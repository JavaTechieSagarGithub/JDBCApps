import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PostgreSQLJdbcDeleteApp {

	private static final String DELETE_COMPANY_SQL = "delete from company where id = ?;";
	final static String url = "jdbc:postgresql://localhost/sagar";
	final static String user = "postgres";
	final static String password = "admin";

	public static void main(String[] args) throws SQLException {

		deleteRecord();
	}
	public static void deleteRecord() throws SQLException {
		System.out.println(DELETE_COMPANY_SQL);
		// Step 1: Establishing a Connection
		Connection connection = DriverManager.getConnection(url, user, password);
		// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(DELETE_COMPANY_SQL);
			preparedStatement.setInt(1, 12);
						
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			preparedStatement.executeUpdate();
			System.out.println("Deleted!");
	}

}
