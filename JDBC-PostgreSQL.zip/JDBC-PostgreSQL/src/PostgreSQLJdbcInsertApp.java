import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PostgreSQLJdbcInsertApp {
	final static String INSERT_COMPANY_SQL = 
			"INSERT INTO company" + "  (id, name, age, address, salary,deptid) VALUES " + " (?, ?, ?, ?, ?,?);";
	final static String url = "jdbc:postgresql://localhost/sagar";
	final static String user = "postgres";
	final static String password = "admin";

	public static void main(String[] args) throws SQLException {

		insertRecord();

	}

	public static void insertRecord() throws SQLException {
		System.out.println(INSERT_COMPANY_SQL);
		// Step 1: Establishing a Connection
		Connection connection = DriverManager.getConnection(url, user, password);

		// Step 2:Create a statement using connection object
		PreparedStatement preparedStatement = connection.prepareStatement(INSERT_COMPANY_SQL);
		preparedStatement.setInt(1, 12);
		preparedStatement.setString(2, "Tony");
		preparedStatement.setInt(3, 25);
		preparedStatement.setString(4, "New York");
		preparedStatement.setInt(5, 25000);
		preparedStatement.setInt(6, 3);
		System.out.println(preparedStatement);
		// Step 3: Execute the query or update query
		preparedStatement.executeUpdate();
		preparedStatement.close();
		connection.close();
	}

}
