import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PostgreSQLJdbcUpdateApp {
	private static final String UPDATE_COMPANY_SQL = "update company set salary = ? where id = ?;";
	final static String url = "jdbc:postgresql://localhost/sagar";
	final static String user = "postgres";
	final static String password = "admin";

	public static void main(String[] args) throws SQLException {
	updateRecord();
	}

	public static void updateRecord() throws SQLException {
		System.out.println(UPDATE_COMPANY_SQL);
		// Step 1: Establishing a Connection
		Connection connection = DriverManager.getConnection(url, user, password);
		// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_COMPANY_SQL);
			preparedStatement.setInt(1, 30000);
			preparedStatement.setInt(2, 10);
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			preparedStatement.executeUpdate();
			System.out.println("Updated!");
	}

}
